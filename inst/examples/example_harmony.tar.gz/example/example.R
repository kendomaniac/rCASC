 library(rCASC)
 path=getwd()
 file=paste(path,"/data/example.csv",sep="")
 metadata=paste(path,"/data/example_metaData.csv",sep="")
 scratch.folder=paste(path,"/scratch",sep="")
 
 harmony(group="sudo", scratch.folder=scratch.folder, file=file,separator=",",meta_data=metadata,usePCA=FALSE)
